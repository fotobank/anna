require '../lib/fancy-buttons'
# Require any additional compass plugins here.

project_type = :stand_alone
css_dir = "stylesheets"
sass_dir = "sass"
images_dir = "images"
relative_assets = true
